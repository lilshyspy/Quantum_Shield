# Quantum Shield backend

Run both services from the Desktop frontend using `npm run start:mac`.

For backend-only development:

```bash
.venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

- GET `/api/health`: health check.
- POST `/api/scan`: `{ "url": "https://example.com" }`.
- POST `/scan`: also accepts `{ "domain": "example.com" }`; returns the same frontend-compatible report.
- POST `/api/ai/analyst`: local rule-based report explanation using server-sent events; no remote AI model.
- GET `/docs`: interactive API documentation.

Scans require a public DNS target and trusted TLS connection. HTTP headers are read on the same pinned connection; redirects are not followed. Unknown checks are reported rather than fabricated. Higher scores mean greater observed safety/readiness. The methodology is included in every report.

Tests: `.venv/bin/python -m unittest discover -s tests -v`.
