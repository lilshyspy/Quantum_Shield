
def classify_certificate_key(algorithm):

    if not algorithm:
        return {
            "algorithm": "Not detected",
            "category": "Unknown",
            "quantum_status": "Unassessed",
            "explanation": "No cryptographic algorithm was detected."
        }

    # Normalize algorithm names for comparison
    key = str(algorithm).upper()
    key = key.replace("-", "").replace("_", "")
    key = key.replace(" ", "").replace("+", "")

    # --------------------------------
    # 1. CLASSICAL PUBLIC-KEY ALGORITHMS
    # --------------------------------

    classical_algorithms = {
        "RSA": "RSA",
        "RSAPSS": "RSA-PSS",
        "ECC": "Elliptic Curve Cryptography",
        "EC": "Elliptic Curve Cryptography",
        "ECDSA": "ECDSA",
        "ECDH": "ECDH",
        "X25519": "X25519",
        "X448": "X448",
        "ED25519": "Ed25519",
        "ED448": "Ed448",
        "DSA": "DSA"
    }

    if key in classical_algorithms:

        return {
            "algorithm": classical_algorithms[key],
            "category": "Classical",
            "quantum_status": "Quantum-vulnerable in principle",
            "explanation": (
                "This is a classical public-key cryptographic "
                "algorithm. Its security can be threatened by "
                "sufficiently powerful fault-tolerant quantum "
                "computers."
            )
        }

    # --------------------------------
    # 2. POST-QUANTUM SIGNATURE ALGORITHMS
    # --------------------------------

    post_quantum_signatures = {
        "MLDSA": "ML-DSA",
        "DILITHIUM": "ML-DSA",
        "SLHDSA": "SLH-DSA",
        "SPHINCS": "SLH-DSA",
        "SPHINCSPLUS": "SLH-DSA"
    }

    if key in post_quantum_signatures:

        return {
            "algorithm": post_quantum_signatures[key],
            "category": "Post-Quantum Signature",
            "quantum_status": "Designed to resist quantum attacks",
            "explanation": (
                "This is a post-quantum digital signature "
                "algorithm designed to resist known "
                "quantum-computing attacks."
            )
        }

    # --------------------------------
    # 3. POST-QUANTUM KEY ESTABLISHMENT
    # --------------------------------

    post_quantum_key_algorithms = {
        "MLKEM": "ML-KEM",
        "KYBER": "ML-KEM"
    }

    if key in post_quantum_key_algorithms:

        return {
            "algorithm": post_quantum_key_algorithms[key],
            "category": "Post-Quantum Key Establishment",
            "quantum_status": "Designed to resist quantum attacks",
            "explanation": (
                "This is a post-quantum key-encapsulation "
                "mechanism designed to establish shared "
                "secrets securely against quantum attacks."
            )
        }

    # --------------------------------
    # 4. UNKNOWN ALGORITHMS
    # --------------------------------

    return {
        "algorithm": algorithm,
        "category": "Unknown",
        "quantum_status": "Unassessed",
        "explanation": (
            "The detected algorithm is not recognized by "
            "QuantumShield. More investigation is required "
            "before assessing its quantum security."
        )
    }

