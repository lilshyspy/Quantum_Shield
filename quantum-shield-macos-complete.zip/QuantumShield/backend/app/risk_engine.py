"""Evidence-based safety scores: 0–100, higher is safer. No hostname heuristics."""
import re
import uuid
from datetime import datetime, timezone


def assess(domain, evidence):
    tls13 = evidence["tlsVersion"] == "TLSv1.3"
    modern = evidence["tlsVersion"] in ("TLSv1.2", "TLSv1.3")
    group = evidence["keyExchange"]
    pq = bool(re.search(r"MLKEM|ML-KEM|Kyber", group, re.I))
    pq_signature = bool(re.search(r"ML[-_]?DSA|SLH[-_]?DSA", evidence["signature"], re.I))
    headers = evidence["headers"]
    hsts_match = re.search(r"(?:^|;)\s*max-age\s*=\s*(\d+)", headers.get("strict-transport-security", ""), re.I)
    hsts = bool(hsts_match and int(hsts_match[1]) > 0)
    csp = bool(headers.get("content-security-policy", "").strip())
    nosniff = headers.get("x-content-type-options", "").lower() == "nosniff"
    referrer = headers.get("referrer-policy", "").lower() in ("no-referrer", "same-origin", "strict-origin", "strict-origin-when-cross-origin")
    classical_parts = [
        ("Modern TLS", 30 if tls13 else 20 if modern else 0, 30),
        ("Trusted, current certificate", 25 if evidence["daysRemaining"] >= 30 else 15, 25),
        ("Public-key strength", 20 if evidence["strongKey"] else 0, 20),
        ("HSTS", 10 if hsts else 0, 10), ("Content Security Policy", 7 if csp else 0, 7),
        ("MIME sniffing protection", 4 if nosniff else 0, 4), ("Referrer policy", 4 if referrer else 0, 4),
    ]
    quantum_parts = [
        ("Post-quantum key exchange", 55 if pq else 0, 55),
        ("Post-quantum handshake signature", 25 if pq_signature else 0, 25),
        ("TLS 1.3", 10 if tls13 else 0, 10),
        ("256-bit symmetric cipher", 10 if evidence["cipherBits"] >= 256 else 0, 10),
    ]
    classical = sum(p[1] for p in classical_parts)
    quantum = sum(p[1] for p in quantum_parts)
    recs = []
    if not pq:
        recs.append("Migrate TLS termination to an ML-KEM hybrid (X25519MLKEM768) before the Q-Day window")
    if not tls13:
        recs.append("Upgrade from TLS 1.2 to TLS 1.3 — legacy ciphers fall first")
    if not hsts:
        recs.append("Publish an HSTS policy with preload to pin the domain to HTTPS")
    if not pq_signature:
        recs.append("Extend ML-DSA coverage to intermediate CA certificates")
    if evidence["daysRemaining"] < 30:
        recs.append("Renew your SSL certificate before it expires.")
    if not recs:
        recs.append("Maintain the current hybrid key-exchange configuration and rotate keys on schedule")
    unknown_group = group.startswith("Unverified")
    limitations = ["One HTTPS endpoint and negotiated connection were inspected; this is not a full vulnerability audit.",
                   "DNSSEC and certificate revocation were not independently verified.",
                   "Scores reflect the documented Quantum Shield checks, not a probability of safety. Unknown checks receive no points."]
    if unknown_group:
        limitations.append("This Python runtime cannot expose the negotiated group; no post-quantum key-exchange points were awarded.")
    if not evidence["headersChecked"]:
        limitations.append("HTTP headers were unavailable; no security-header points were awarded.")
    if not pq_signature:
        limitations.append("Post-quantum authentication was not observed, even if a hybrid key exchange was negotiated.")
    return {
        "domain": domain, "scannedAt": int(datetime.now(timezone.utc).timestamp() * 1000),
        "reportId": "QS-" + uuid.uuid4().hex[:16].upper(), "simulated": False,
        "classicalScore": classical, "quantumScore": quantum,
        "classicalVerdict": "SECURE" if classical >= 75 else "CAUTION" if classical >= 50 else "VULNERABLE",
        "quantumVerdict": "PQC READY" if quantum >= 85 else "HYBRID READY" if quantum >= 60 else "AT RISK" if quantum >= 30 else "CRITICAL RISK",
        "crypto": {
            "tlsVersion": evidence["tlsVersion"].replace("TLSv", "TLS "), "keyExchange": group,
            "sigAlgorithm": evidence["signature"],
            "certificate": f"X.509 {evidence['algorithm']}" + (f"-{evidence['keyBits']}" if evidence['keyBits'] else "") + " — trusted certificate",
            "hsts": "Enabled" if hsts else "Missing" if evidence["headersChecked"] else "Unverified",
            "dnssec": "Unverified — not inspected",
        },
        "pqcStatus": "ML-KEM hybrid key exchange detected" if pq else "Post-quantum support unverified" if unknown_group else "No post-quantum support detected",
        "qdayVulnerability": "LOW — hybrid key exchange detected; classical authentication remains a migration priority" if pq else
            "UNASSESSED — negotiated key exchange could not be verified" if unknown_group else
            "ELEVATED — classical key exchange is harvestable today and factorable after Q-Day" if tls13 else
            "HIGH — harvest-now-decrypt-later threat is active against all recorded sessions",
        "recommendations": recs, "limitations": limitations, "evidence": evidence,
        "scoreMethod": {"version": "QS-2.0", "direction": "Higher scores indicate greater observed safety / readiness.",
                        "classical": [{"check": n, "earned": e, "maximum": m} for n,e,m in classical_parts],
                        "quantum": [{"check": n, "earned": e, "maximum": m} for n,e,m in quantum_parts]},
    }
