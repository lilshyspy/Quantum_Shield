"""Read-only HTTPS inspection. Pin validated DNS addresses and never follow redirects."""
import http.client
import ipaddress
import re
import socket
import ssl
from urllib.parse import urlsplit
from datetime import datetime, timezone
import certifi
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, ec, ed25519, ed448


def normalize_target(raw):
    raw = raw.strip()
    if not raw or any(ord(c) < 33 for c in raw):
        raise ValueError("Enter a valid public website domain.")
    parsed = urlsplit(raw if "://" in raw else "https://" + raw)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 80, 443):
        raise ValueError("Use a public HTTP(S) website on port 443.")
    domain = parsed.hostname.encode("idna").decode("ascii").lower().rstrip(".")
    if len(domain) > 253 or not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in domain.split(".")):
        raise ValueError("Enter a valid public website domain.")
    if domain == "localhost" or domain.endswith((".localhost", ".local")):
        raise ValueError("Private or local targets are not supported.")
    return domain


def resolve_public(domain):
    addresses = socket.getaddrinfo(domain, 443, type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(item[4][0]).is_global for item in addresses):
        raise ValueError("Private or non-public targets are not allowed.")
    return list(dict.fromkeys(item[4][0] for item in addresses))


def inspect_tls(domain, addresses):
    context = ssl.create_default_context(cafile=certifi.where())
    context.set_alpn_protocols(["http/1.1"])
    last_error = None
    for address in addresses[:2]:
        try:
            # Numeric address prevents a second DNS lookup / rebinding.
            with socket.create_connection((address, 443), timeout=5) as connection:
                with context.wrap_socket(connection, server_hostname=domain) as secure:
                    cert = x509.load_der_x509_certificate(secure.getpeercert(binary_form=True))
                    key = cert.public_key()
                    algorithm = "Unknown"
                    strong = False
                    if isinstance(key, rsa.RSAPublicKey):
                        algorithm, strong = "RSA", key.key_size >= 2048
                    elif isinstance(key, ec.EllipticCurvePublicKey):
                        algorithm, strong = "ECDSA", key.key_size >= 256
                    elif isinstance(key, (ed25519.Ed25519PublicKey, ed448.Ed448PublicKey)):
                        algorithm, strong = type(key).__name__.replace("PublicKey", ""), True
                    cipher = secure.cipher()
                    group = secure.group() if hasattr(secure, "group") else None
                    signature = secure.server_sigalg() if hasattr(secure, "server_sigalg") else None
                    result = {
                        "tlsVersion": secure.version(), "cipher": cipher[0], "cipherBits": cipher[2],
                        "keyExchange": group or "Unverified — negotiated group unavailable in this Python runtime",
                        "signature": signature or cert.signature_algorithm_oid._name or cert.signature_algorithm_oid.dotted_string,
                        "algorithm": algorithm, "keyBits": getattr(key, "key_size", None), "strongKey": strong,
                        "certificateValid": True, "issuer": cert.issuer.rfc4514_string(),
                        "expiresAt": cert.not_valid_after_utc.isoformat(),
                        "daysRemaining": (cert.not_valid_after_utc - datetime.now(timezone.utc)).days,
                        "fingerprint": cert.fingerprint(hashes.SHA256()).hex().upper(),
                        "address": address, "headers": {}, "headersChecked": False,
                    }
                    try:
                        secure.sendall((f"GET / HTTP/1.1\r\nHost: {domain}\r\nUser-Agent: QuantumShield/2.0\r\nConnection: close\r\n\r\n").encode("ascii"))
                        response = http.client.HTTPResponse(secure)
                        response.begin()
                        result.update(headers={k.lower(): v for k, v in response.getheaders()}, headersChecked=True, httpStatus=response.status)
                        response.close()  # Only read headers; do not download the site or follow redirects.
                    except (OSError, http.client.HTTPException):
                        result["headerError"] = "HTTP response headers could not be inspected."
                    return result
        except (OSError, ssl.SSLError, ValueError) as error:
            last_error = error
    raise ConnectionError(f"TLS inspection could not complete: {last_error}")
