"""Quantum Shield local API. Run using .venv/bin/python -m uvicorn main:app."""
import json
import socket
from threading import BoundedSemaphore
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from app.tls_discovery import normalize_target, resolve_public, inspect_tls
from app.risk_engine import assess

app = FastAPI(title="Quantum Shield", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
slots = BoundedSemaphore(4)

class ScanRequest(BaseModel):
    url: Optional[str] = Field(default=None, max_length=2048)
    domain: Optional[str] = Field(default=None, max_length=2048)

@app.get("/")
@app.get("/health")
@app.get("/api/health")
def health():
    return {"status": "healthy", "service": "Quantum Shield", "version": "2.0.0", "mode": "live"}

@app.post("/scan")
@app.post("/api/scan")
def scan(data: ScanRequest):
    if not slots.acquire(blocking=False):
        raise HTTPException(429, "Scanner is busy. Please try again shortly.")
    try:
        domain = normalize_target(data.url or data.domain or "")
        addresses = resolve_public(domain)
        return assess(domain, inspect_tls(domain, addresses))
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    except socket.gaierror as error:
        raise HTTPException(400, "Domain could not be resolved.") from error
    except ConnectionError as error:
        raise HTTPException(502, str(error)) from error
    finally:
        slots.release()

class AnalystRequest(BaseModel):
    session_id: str = Field(max_length=128)
    message: str = Field(min_length=1, max_length=4000)
    scan_context: Optional[dict] = None

@app.get("/api/ai/analyst/history/{session_id}")
def history(session_id: str):
    return []

@app.post("/api/ai/analyst")
def analyst(data: AnalystRequest):
    # No API key or cloud model was supplied. Provide a transparent local explanation.
    context = data.scan_context or {}
    message = data.message.lower()
    if "harvest" in message:
        answer = "Harvest-now-decrypt-later means recording encrypted traffic now to attempt decryption with a future cryptographically relevant quantum computer. Hybrid ML-KEM key exchange addresses this migration risk."
    elif "q-day" in message or "qday" in message:
        answer = "Q-Day is a hypothetical point when quantum computers can break widely used classical public-key cryptography. Its date is uncertain; the website timeline is illustrative, not a prediction verified by the scanner."
    elif context:
        answer = f"{context.get('domain', 'This target')}: classical safety {context.get('classicalScore', '?')}/100; quantum readiness {context.get('quantumScore', '?')}/100. Higher is safer.\n\n" + context.get("pqcStatus", "") + "\n\n" + "\n".join(context.get("recommendations", [])) + "\n\n" + "\n".join(context.get("limitations", []))
    else:
        answer = "ML-KEM supports post-quantum key establishment; ML-DSA and SLH-DSA support post-quantum signatures. Run a scan to inspect the target’s observed TLS configuration and recommended next steps."
    content = "Local report assistant — no ChatGPT model is connected.\n\n" + answer
    return StreamingResponse(iter(["data: " + json.dumps({"delta": content}) + "\n\n", "data: {\"done\":true}\n\n"]), media_type="text/event-stream")
