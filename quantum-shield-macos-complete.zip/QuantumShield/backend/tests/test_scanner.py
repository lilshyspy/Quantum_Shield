import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from main import app
from app.tls_discovery import normalize_target, resolve_public
from app.risk_engine import assess


def evidence(**changes):
    value = dict(tlsVersion="TLSv1.3", keyExchange="X25519", signature="ecdsa_secp256r1_sha256", algorithm="ECDSA", keyBits=256, strongKey=True, certificateValid=True, daysRemaining=80, cipherBits=256, headers={}, headersChecked=True)
    value.update(changes)
    return value

class ScoringTests(unittest.TestCase):
    def test_higher_means_safer(self):
        base = assess("example.com", evidence())
        hardened = assess("example.com", evidence(headers={"strict-transport-security":"max-age=31536000", "content-security-policy":"default-src 'self'", "x-content-type-options":"nosniff", "referrer-policy":"no-referrer"}))
        self.assertEqual(base["classicalScore"], 75)
        self.assertEqual(hardened["classicalScore"], 100)
        self.assertGreater(hardened["classicalScore"], base["classicalScore"])
        self.assertEqual(base["quantumScore"], 20)
        self.assertEqual(base["quantumVerdict"], "CRITICAL RISK")
    def test_hybrid_not_full_pqc(self):
        result = assess("example.com", evidence(keyExchange="X25519MLKEM768"))
        self.assertEqual(result["quantumScore"], 75)
        self.assertEqual(result["quantumVerdict"], "HYBRID READY")
    def test_unknown_not_credited(self):
        result = assess("example.com", evidence(keyExchange="Unverified — runtime"))
        self.assertEqual(result["quantumScore"], 20)
        self.assertIn("unverified", result["pqcStatus"])
    def test_disabled_hsts_not_credited(self):
        self.assertEqual(assess("example.com", evidence(headers={"strict-transport-security":"max-age=0"}))["classicalScore"],75)
    def test_weaker_certificate_reduces_safety(self):
        self.assertLess(assess("example.com", evidence(strongKey=False, daysRemaining=5))["classicalScore"],75)
    def test_private_dns_rejected(self):
        with patch("socket.getaddrinfo",return_value=[(2,1,6,"",("127.0.0.1",443))]):
            with self.assertRaises(ValueError): resolve_public("example.com")
    def test_invalid_target(self):
        for target in ["", "localhost", "https://user:password@example.com", "https://example.com:444", "https://bad.com\r\nHost:x", "https://-bad.com"]:
            with self.subTest(target=target), self.assertRaises(ValueError): normalize_target(target)
    def test_both_frontend_and_legacy_request(self):
        with TestClient(app) as client, patch("main.resolve_public",return_value=["93.184.215.14"]), patch("main.inspect_tls",return_value=evidence()):
            for path,body in [("/api/scan",{"url":"https://example.com"}),("/scan",{"domain":"example.com"})]:
                result=client.post(path,json=body)
                self.assertEqual(result.status_code,200)
                self.assertFalse(result.json()["simulated"])
                self.assertIn("crypto",result.json())
    def test_failed_scan_has_no_fake_score(self):
        with TestClient(app) as client, patch("main.resolve_public",return_value=["93.184.215.14"]), patch("main.inspect_tls",side_effect=ConnectionError("TLS failed")):
            result=client.post("/api/scan",json={"url":"https://example.com"})
            self.assertEqual(result.status_code,502)
            self.assertNotIn("quantumScore",result.json())
    def test_local_analyst_stream(self):
        with TestClient(app) as client:
            result=client.post("/api/ai/analyst",json={"session_id":"test", "message":"What is Q-Day?"})
            self.assertIn("no ChatGPT model is connected",result.text)
            self.assertIn("data:",result.text)

if __name__ == "__main__": unittest.main()
