# Backend integration

The supplied backend is now connected. Read [MACOS_SETUP.md](MACOS_SETUP.md).

Default mode is `api`; Vite forwards `/api` to `http://127.0.0.1:8000`. The API implements the existing frontend response schema. Set `VITE_SCAN_MODE=demo` explicitly to use illustrative browser data. A failed live scan does not silently fall back to demo data.

Start both servers using `npm run start:mac`.
