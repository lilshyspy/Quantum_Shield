# Quantum Shield on macOS

Frontend: `~/Desktop/quantum-shield-frontend`
Backend: `~/Downloads/QuantumShield/backend`

Open `QuantumShield.code-workspace` in VS Code to see both folders.

## Start

In the frontend terminal:

```bash
npm run start:mac
```

Open http://localhost:5173. Both servers run together; Ctrl+C stops both.
Alternatively: VS Code → Terminal → Run Task → Start Quantum Shield.
API documentation: http://localhost:8000/docs.

## First-time installation / another Mac

Install Node.js and Python 3.11 or later (3.15 recommended for TLS group detection).

```bash
cd ~/Desktop/quantum-shield-frontend
npm run setup:mac
npm run start:mac
```

The Windows `venv` is not used. The backend uses its own macOS `.venv`.
For a different backend location, export `QS_BACKEND_DIR=/absolute/path/to/backend` before running either command.
All development servers bind to loopback. This is a local development setup, not a public deployment.

## What changed

- Dark emerald/cyan certificate, assessment reference, UTC issue time, two-page A4 print layout, technical evidence, score breakdown, remediation, and limits.
- Risk report headings, verdict names, narrative simulator and existing report components are preserved. Operational labels now distinguish live scans from demo mode.
- Frontend defaults to live `/api/scan` through Vite’s local proxy. `VITE_SCAN_MODE=demo` explicitly enables the original illustrative scanner.
- Backend uses a validated, pinned public IP with hostname-verified TLS, reads HTTP headers without following redirects, and returns the frontend schema. TLS failures return an error rather than an invented score.
- DNSSEC, revocation, application vulnerabilities and other unperformed checks remain unverified.
- Chat provides a clearly labelled local, rule-based explanation. No ChatGPT account or API key is configured; no paid AI calls are made. Conversation is kept in the current frontend session only.

## Scoring: higher is safer

Classical safety: TLS version 30, trusted/current certificate 25, public-key strength 20, HSTS 10, CSP presence 7, nosniff 4, restrictive referrer policy 4. TLS 1.2 earns 20/30; a certificate expiring in under 30 days earns 15/25. These checks do not prove the site is free of vulnerabilities.

Quantum readiness: observed post-quantum/hybrid key exchange 55, post-quantum TLS handshake signature 25, TLS 1.3 10, 256-bit symmetric cipher 10. A hybrid exchange with classical authentication cannot receive full marks. Missing evidence earns no points. On older Python versions, key exchange may be unverified.

Classical verdicts: 75+ SECURE, 50+ CAUTION, otherwise VULNERABLE.
Quantum verdicts: 85+ PQC READY, 60+ HYBRID READY, 30+ AT RISK, otherwise CRITICAL RISK.

The certificate records an automated assessment. “QS CERTIFIED” is the product’s record badge, not an independent certification. It is not digitally signed or publicly verifiable. The Q-Day animation and telemetry are illustrative; they do not execute quantum attacks.

## Print / PDF

Run a scan, click Print / Save as PDF, select A4 and Save as PDF. Use 100% scale, disable browser headers/footers, and enable background graphics for the dark design. The normal report produces a certificate page and a technical appendix; unusually long backend values can require more pages.

## Validation

```bash
npm run build
cd ~/Downloads/QuantumShield/backend
.venv/bin/python -m unittest discover -s tests -v
```

Backend runtime packages are pinned in `requirements-lock.txt`. Python’s TLS group API: https://docs.python.org/3/library/ssl.html#ssl.SSLSocket.group
FastAPI server guidance: https://fastapi.tiangolo.com/deployment/manually/
