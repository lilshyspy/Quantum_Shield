# Quantum Shield

Live TLS security and quantum-readiness assessment with a printable certificate.

Open `QuantumShield.code-workspace` in VS Code. Then select **Terminal → Run Task → Start Quantum Shield**, or run:

```bash
npm run start:mac
```

Visit http://localhost:5173. Both the frontend and backend start together.

See [macOS setup and scoring guide](MACOS_SETUP.md) for installation, limitations, certificate printing, and commands.

The original Windows virtual environment is not used. The backend has a fresh macOS `.venv`. Chat currently uses a clearly labelled local report assistant; it is not connected to ChatGPT.
