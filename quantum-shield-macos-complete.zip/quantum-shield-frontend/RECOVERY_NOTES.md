# Source recovery and package changes

Source page:
https://pq-shield--90nm8nnc.preview.emergentagent.com/?utm_source=share

App sources were recovered from the publicly served `/static/js/bundle.js.map`. Original CSS was recovered from the nested CSS-loader source maps; the full compiled stylesheet was recovered from the served CSS module. `original-source/src/` preserves all 18 app source files recovered in this way. This is app source, not just a screenshot recreation or a minified bundle.

The original project manifest, lockfile, server source, and build configuration were not exposed in that source map. This package supplies a new Vite configuration, dependency manifest, and resolved lockfile. src/App.js and src/index.js are named App.jsx and index.jsx in the runnable project to support JSX in Vite. Component layout and animation definitions are retained. Original fonts load from Google Fonts.

Integration changes in the runnable src/ tree:

- New src/lib/api.js separates scan transport from the UI, with demo/API modes and response validation.
- App.jsx awaits backend results while keeping the original animation timing and handles failures without showing simulated reports.
- VerdictReport.jsx labels simulated data or a backend report appropriately.
- AIAnalyst.jsx uses the configured API URL, handles HTTP failures, and explains the disconnected state in demo mode.

No Emergent preview overlay, recording scripts, telemetry scripts, or development server bundle is required or included. The source ZIP contains app source, generated static build, config, lockfile, and integration documentation. node_modules and real environment files are excluded.

The quantum attack script, sample security data, forecast dates and other original presentation copy have been preserved. They are illustrative UI content, not additional cryptographic testing implemented by this extraction.
