import { useCallback, useEffect, useRef, useState } from "react";
import { Toaster, toast } from "sonner";
import Lenis from "lenis";
import "@/App.css";
import Header from "@/components/Header";
import HeroScanner from "@/components/HeroScanner";
import QuantumCanvasBackground from "@/components/QuantumCanvasBackground";
import ScanAnimation from "@/components/ScanAnimation";
import VerdictReport from "@/components/VerdictReport";
import QuantumHackSimulation from "@/components/QuantumHackSimulation";
import AIAnalyst from "@/components/AIAnalyst";
import ScanHistory from "@/components/ScanHistory";
import ThreatTicker from "@/components/ThreatTicker";
import EditorialMarquee from "@/components/EditorialMarquee";
import Footer from "@/components/Footer";
import { scanDomain, normalizeDomain } from "@/lib/scanner";

const SCAN_STAGES = [
    "Resolving DNS records…",
    "TLS handshake — probing cipher suites…",
    "Auditing certificate chain & key strength…",
    "Interrogating key exchange — classical vs hybrid…",
    "Checking post-quantum headers (ML-KEM / X25519MLKEM768)…",
    "Compiling Q-Day exposure report…",
];
const STAGE_MS = 480;

function loadHistory() {
    try {
        const raw = localStorage.getItem("quantum_shield_scan_history");
        const parsed = raw ? JSON.parse(raw) : [];
        return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
    } catch {
        return [];
    }
}

function IdleReport() {
    return (
        <div data-testid="report-idle-state" className="qs-glass rounded-lg px-6 py-14 text-center">
            <p className="font-mono text-xs text-slate-600 tracking-[0.25em]">// AWAITING TARGET</p>
            <p className="mt-3 font-mono text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
                Enter a domain above — Quantum Shield compiles its classical & quantum threat report in-browser. No data leaves this tab.
            </p>
        </div>
    );
}

export default function App() {
    const [phase, setPhase] = useState("idle");
    const [scanInput, setScanInput] = useState("");
    const [target, setTarget] = useState("");
    const [stageIdx, setStageIdx] = useState(0);
    const [result, setResult] = useState(null);
    const [history, setHistory] = useState(loadHistory);
    const timers = useRef([]);

    useEffect(() => {
        const lenis = new Lenis({ duration: 1.15, smoothWheel: true });
        window.__lenis = lenis;
        let raf;
        const loop = (t) => {
            lenis.raf(t);
            raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);
        return () => {
            cancelAnimationFrame(raf);
            lenis.destroy();
            window.__lenis = null;
        };
    }, []);

    useEffect(() => () => timers.current.forEach(clearTimeout), []);

    const pushHistory = useCallback((res) => {
        setHistory((prev) => {
            const next = [
                {
                    domain: res.domain,
                    classicalScore: res.classicalScore,
                    classicalVerdict: res.classicalVerdict,
                    quantumScore: res.quantumScore,
                    quantumVerdict: res.quantumVerdict,
                    ts: Date.now(),
                },
                ...prev.filter((h) => h.domain !== res.domain),
            ].slice(0, 8);
            try {
                localStorage.setItem("quantum_shield_scan_history", JSON.stringify(next));
            } catch {}
            return next;
        });
    }, []);

    const scrollToHash = (hash) => {
        if (window.__lenis) window.__lenis.scrollTo(hash, { offset: -72 });
        else document.querySelector(hash)?.scrollIntoView({ behavior: "smooth" });
    };

    const runScan = useCallback(
        (raw) => {
            if (phase === "scanning") return;
            const domain = normalizeDomain(raw);
            if (!domain) {
                toast.error("Enter a valid domain — e.g. https://example.com");
                return;
            }
            timers.current.forEach(clearTimeout);
            timers.current = [];
            setScanInput(domain);
            setTarget(domain);
            setStageIdx(0);
            setResult(null);
            setPhase("scanning");

            SCAN_STAGES.forEach((_, i) => {
                if (i > 0) timers.current.push(setTimeout(() => setStageIdx(i), i * STAGE_MS));
            });
            timers.current.push(
                setTimeout(() => {
                    const res = scanDomain(domain);
                    setResult(res);
                    setPhase("done");
                    if (res) pushHistory(res);
                    timers.current.push(setTimeout(() => scrollToHash("#report"), 150));
                }, SCAN_STAGES.length * STAGE_MS + 250),
            );
        },
        [phase, pushHistory],
    );

    const clearHistory = () => {
        setHistory([]);
        try {
            localStorage.removeItem("quantum_shield_scan_history");
        } catch {}
        toast.success("Scan log purged.");
    };

    return (
        <div className="relative min-h-screen bg-qs-base text-[#F0F4F1] overflow-x-clip">
            <QuantumCanvasBackground />
            <div className="qs-vignette" />
            <div className="qs-noise" />
            <Header />

            <main className="relative z-10">
                <HeroScanner onScan={runScan} scanning={phase === "scanning"} input={scanInput} setInput={setScanInput} />
                <ThreatTicker />
                <EditorialMarquee />

                <section id="report" data-testid="verdict-report-section" className="relative py-16 sm:py-24 lg:py-32">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
                            <div className="min-w-0">
                                <p className="font-mono text-[11px] tracking-[0.28em] text-qs-green/80">01 // THREAT REPORT</p>
                                <h2 className="font-display font-bold text-2xl sm:text-3xl tracking-tight mt-2 truncate">
                                    {result ? result.domain : "DUAL-VERDICT SCAN"}
                                </h2>
                            </div>
                            <p className="font-mono text-[10px] text-slate-600 tracking-[0.2em]">Q-DAY EST: 2029–2033</p>
                        </div>

                        {phase === "scanning" && <ScanAnimation domain={target} stageIdx={stageIdx} stages={SCAN_STAGES} />}
                        {phase === "done" && result && <VerdictReport result={result} />}
                        {phase === "idle" && <IdleReport />}
                    </div>
                </section>

                <QuantumHackSimulation result={phase === "done" ? result : null} />
                <AIAnalyst result={phase === "done" ? result : null} />
                <ScanHistory history={history} onRescan={runScan} onClear={clearHistory} />
            </main>

            <div className="relative z-10">
                <Footer />
            </div>

            <Toaster theme="dark" position="bottom-right" />
        </div>
    );
}
