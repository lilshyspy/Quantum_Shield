const ITEMS = [
    "NIST FIPS 203 — ML-KEM",
    "NIST FIPS 204 — ML-DSA",
    "NIST FIPS 205 — SLH-DSA",
    "CNSA 2.0 COMPLIANCE",
    "SHOR'S ALGORITHM RESISTANCE",
    "HARVEST-NOW-DECRYPT-LATER",
    "X25519MLKEM768",
    "TLS 1.3 + PQC",
];

function Row({ hidden }) {
    return (
        <div aria-hidden={hidden || undefined} className="flex shrink-0 items-center">
            {ITEMS.map((it) => (
                <span key={it} className="flex items-center font-mono text-xs sm:text-sm tracking-[0.22em] text-slate-500 whitespace-nowrap">
                    <span className="px-6 sm:px-10">{it}</span>
                    <span className="h-1.5 w-1.5 rotate-45 bg-qs-green/70 inline-block" />
                </span>
            ))}
        </div>
    );
}

export default function EditorialMarquee() {
    return (
        <div className="relative overflow-hidden border-b qs-hairline py-5" data-testid="editorial-marquee">
            <div className="qs-marquee-track flex w-max">
                <Row />
                <Row hidden />
            </div>
            <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-qs-base to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-qs-base to-transparent" />
        </div>
    );
}
