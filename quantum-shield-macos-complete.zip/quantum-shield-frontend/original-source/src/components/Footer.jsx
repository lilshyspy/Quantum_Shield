import Logo from "./Logo";

export default function Footer() {
    return (
        <footer className="relative border-t qs-hairline py-12 bg-qs-term/40">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row gap-8 md:items-center justify-between">
                <div className="flex items-center gap-3">
                    <Logo className="h-8 w-8" />
                    <div>
                        <p className="font-display font-bold text-sm">
                            QUANTUM<span className="text-qs-green">SHIELD</span>
                        </p>
                        <p className="font-mono text-[10px] text-slate-600 tracking-[0.22em] mt-0.5">POST-QUANTUM READINESS SCANNER</p>
                    </div>
                </div>

                <div className="font-mono text-[10px] text-slate-600 leading-5 max-w-md">
                    <p>REFERENCES: NIST FIPS 203 / 204 / 205 · CNSA 2.0 · CRYSTALS-KYBER / DILITHIUM</p>
                    <p className="mt-1">VERDICTS COME FROM AN IN-BROWSER HEURISTIC MODEL — SIMULATION ONLY, NOT A PROFESSIONAL AUDIT.</p>
                </div>

                <div className="flex items-center gap-2 font-mono text-[10px] text-slate-500 whitespace-nowrap">
                    <span className="qs-pulse-dot w-1.5 h-1.5 rounded-full bg-qs-green" />
                    ALL SYSTEMS NOMINAL — © {new Date().getFullYear()} QUANTUM SHIELD
                </div>
            </div>
        </footer>
    );
}
