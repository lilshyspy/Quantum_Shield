import { motion } from "framer-motion";
import Logo from "./Logo";

const LINKS = [
    ["#scanner", "SCANNER"],
    ["#report", "REPORT"],
    ["#simulation", "SIMULATION"],
    ["#analyst", "ANALYST"],
    ["#history", "HISTORY"],
];

export const scrollToHash = (href) => {
    if (window.__lenis) window.__lenis.scrollTo(href, { offset: -72 });
    else document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
};

export default function Header() {
    const go = (e, href) => {
        e.preventDefault();
        scrollToHash(href);
    };
    return (
        <motion.header
            initial={{ y: -64, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            data-testid="header-nav"
            className="fixed top-0 inset-x-0 z-50 qs-glass border-b qs-hairline"
        >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
                <a
                    href="#scanner"
                    onClick={(e) => go(e, "#scanner")}
                    data-testid="quantum-shield-logo"
                    className="flex items-center gap-2.5 shrink-0"
                >
                    <Logo className="h-7 w-7" />
                    <span className="font-display font-bold tracking-tight text-sm sm:text-base">
                        QUANTUM<span className="text-qs-green qs-text-glow-green">SHIELD</span>
                    </span>
                </a>

                <nav className="hidden md:flex items-center gap-7 font-mono text-[11px] tracking-[0.18em] text-slate-400">
                    {LINKS.map(([href, label]) => (
                        <a
                            key={href}
                            href={href}
                            onClick={(e) => go(e, href)}
                            className="hover:text-qs-green transition-colors duration-200"
                        >
                            {label}
                        </a>
                    ))}
                </nav>

                <div
                    data-testid="qday-countdown-pill"
                    className="flex items-center gap-2.5 font-mono text-[10px] sm:text-[11px] tracking-[0.14em] text-qs-green border border-qs-green/25 bg-qs-green/5 rounded-full px-3 py-1.5 whitespace-nowrap"
                >
                    <span className="qs-pulse-dot w-1.5 h-1.5 rounded-full bg-qs-green inline-block shrink-0" />
                    <span className="sm:hidden">Q-DAY · 2,410D</span>
                    <span className="hidden sm:inline">Q-DAY COUNTDOWN: ~2,410 DAYS</span>
                </div>
            </div>
        </motion.header>
    );
}
