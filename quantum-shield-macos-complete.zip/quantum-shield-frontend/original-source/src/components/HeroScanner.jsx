import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Scan, ChevronRight } from "lucide-react";

const SAMPLES = [
    { domain: "google.com", testid: "sample-chip-google.com" },
    { domain: "cloudflare.com", testid: "sample-chip-cloudflare.com" },
    { domain: "legacy-bank.com", testid: "sample-chip-legacy-bank.com" },
    { domain: "quantumready.gov", testid: "sample-chip-quantumready.gov" },
];

const STATUS_ROWS = [
    ["SHOR ENGINE", "ARMED", "text-qs-amber"],
    ["LATTICE DEFENSE", "ONLINE", "text-qs-green"],
    ["Q-DAY WINDOW", "2029—2033", "text-qs-cyan"],
    ["MODEL", "IN-BROWSER v2.4", "text-slate-300"],
];

const lineReveal = {
    hidden: { y: "115%" },
    show: (i) => ({
        y: "0%",
        transition: { duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.25 + i * 0.13 },
    }),
};

export default function HeroScanner({ onScan, scanning, input, setInput }) {
    const ref = useRef(null);
    const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
    const parallaxY = useTransform(scrollYProgress, [0, 1], [0, 140]);
    const fade = useTransform(scrollYProgress, [0, 0.85], [1, 0.15]);

    const submit = (e) => {
        e.preventDefault();
        onScan(input);
    };

    return (
        <section
            id="scanner"
            data-testid="hero-section"
            ref={ref}
            className="relative min-h-screen flex items-center pt-28 pb-20"
        >
            <motion.div style={{ y: parallaxY, opacity: fade }} className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-12 gap-10 items-end">
                    <div className="lg:col-span-8">
                        <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.15, duration: 0.8 }}
                            className="font-mono text-[10px] sm:text-xs tracking-[0.28em] text-qs-green/80 mb-6"
                        >
                            // POST-QUANTUM READINESS SCANNER — BUILD 2.4.1
                        </motion.p>

                        <h1 className="font-display font-extrabold tracking-tight leading-[1.04] text-[2rem] sm:text-6xl lg:text-7xl">
                            <span className="block overflow-hidden pb-1">
                                <motion.span custom={0} variants={lineReveal} initial="hidden" animate="show" className="block">
                                    ENCRYPTION, AS YOU
                                </motion.span>
                            </span>
                            <span className="block overflow-hidden pb-1">
                                <motion.span custom={1} variants={lineReveal} initial="hidden" animate="show" className="block">
                                    KNOW IT, HAS AN
                                </motion.span>
                            </span>
                            <span className="block overflow-hidden pb-1">
                                <motion.span custom={2} variants={lineReveal} initial="hidden" animate="show" className="block">
                                    <span className="text-qs-green qs-text-glow-green">EXPIRY DATE.</span>
                                </motion.span>
                            </span>
                        </h1>

                        <motion.p
                            initial={{ opacity: 0, y: 16 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.85, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                            className="mt-7 max-w-xl text-sm sm:text-base leading-relaxed text-slate-400"
                        >
                            Quantum Shield audits any domain for the threats of today — and scores its readiness for the
                            cryptographically-relevant quantum computers of the next decade. Everything runs in your browser.
                        </motion.p>

                        <motion.form
                            initial={{ opacity: 0, y: 16 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                            onSubmit={submit}
                            className="mt-9 flex flex-col sm:flex-row gap-3 max-w-2xl"
                        >
                            <div className="relative flex-1">
                                <Scan className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-qs-green/70" />
                                <input
                                    data-testid="domain-scan-input"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="https://yourdomain.com"
                                    spellCheck="false"
                                    autoCapitalize="none"
                                    autoComplete="off"
                                    className="qs-input w-full h-14 pl-12 pr-4 rounded-md bg-qs-term/80 border qs-hairline font-mono text-sm text-[#F0F4F1] placeholder:text-slate-600 transition-all duration-200"
                                />
                            </div>
                            <button
                                data-testid="scan-submit-button"
                                type="submit"
                                disabled={scanning}
                                className="group h-14 px-7 rounded-md bg-qs-green text-qs-base font-mono text-xs font-bold tracking-[0.2em] hover:bg-[#4dffa0] hover:shadow-[0_0_44px_rgba(0,255,102,0.35)] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shrink-0"
                            >
                                {scanning ? "SCANNING…" : "INITIATE SCAN"}
                                <ChevronRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
                            </button>
                        </motion.form>

                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 1.2, duration: 0.8 }}
                            className="mt-5 flex flex-wrap items-center gap-2 font-mono text-[11px]"
                        >
                            <span className="tracking-[0.22em] text-slate-600 mr-1">TRY:</span>
                            {SAMPLES.map((s) => (
                                <button
                                    key={s.domain}
                                    data-testid={s.testid}
                                    onClick={() => onScan(s.domain)}
                                    disabled={scanning}
                                    className="px-3 py-1.5 rounded-full border qs-hairline text-slate-300 hover:border-qs-green/50 hover:text-qs-green transition-colors duration-200 bg-qs-term/50 disabled:opacity-50"
                                >
                                    {s.domain}
                                </button>
                            ))}
                        </motion.div>
                    </div>

                    <motion.div
                        initial={{ opacity: 0, x: 24 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.1, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                        className="hidden lg:block lg:col-span-4"
                    >
                        <div className="qs-glass rounded-md p-5 font-mono text-[11px]">
                            <p className="text-slate-500 tracking-[0.22em] mb-2">LIVE MODEL STATUS</p>
                            {STATUS_ROWS.map(([k, v, c]) => (
                                <div key={k} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                                    <span className="text-slate-600 tracking-widest">{k}</span>
                                    <span className={c}>{v}</span>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </motion.div>
        </section>
    );
}
