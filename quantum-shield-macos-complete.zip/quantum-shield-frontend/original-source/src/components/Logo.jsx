export default function Logo({ className = "h-7 w-7" }) {
    return (
        <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
            <path
                d="M16 3.5 L26.5 7.6 V15 C26.5 21.8 22 26.4 16 28.6 C10 26.4 5.5 21.8 5.5 15 V7.6 Z"
                stroke="#00FF66"
                strokeWidth="1.8"
                strokeLinejoin="round"
            />
            <g transform="rotate(-18 16 15)">
                <ellipse cx="16" cy="15" rx="6.2" ry="2.5" stroke="#00E5FF" strokeWidth="1.1" opacity="0.9" />
            </g>
            <g transform="rotate(24 16 15)">
                <ellipse cx="16" cy="15" rx="6.2" ry="2.5" stroke="#00E5FF" strokeWidth="1.1" opacity="0.5" />
            </g>
            <circle cx="16" cy="15" r="1.7" fill="#00FF66" />
        </svg>
    );
}
