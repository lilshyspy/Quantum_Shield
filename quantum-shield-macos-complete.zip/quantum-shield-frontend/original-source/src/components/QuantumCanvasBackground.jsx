import { useEffect, useRef } from "react";

const SHIELD = [
    [-0.62, -0.72],
    [0.62, -0.72],
    [0.82, -0.42],
    [0.82, 0.08],
    [0.52, 0.58],
    [0, 0.92],
    [-0.52, 0.58],
    [-0.82, 0.08],
    [-0.82, -0.42],
];

function bottomY(x) {
    return 0.08 + 0.84 * (1 - Math.abs(x) / 0.82);
}
function halfWidth(y) {
    if (y <= -0.42) return 0.62 + 0.2 * ((y + 0.72) / 0.3);
    if (y <= 0.08) return 0.82;
    return Math.max(0, 0.82 * (1 - (y - 0.08) / 0.84));
}

export default function QuantumCanvasBackground() {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext("2d");
        let raf, w, h, dpr;
        const mouse = { x: 0.5, y: 0.5 };
        const particles = Array.from({ length: 70 }, () => ({
            x: Math.random(),
            y: Math.random(),
            d: 0.25 + Math.random() * 0.75,
            s: Math.random() * Math.PI * 2,
        }));

        const resize = () => {
            dpr = Math.min(window.devicePixelRatio || 1, 2);
            w = window.innerWidth;
            h = window.innerHeight;
            canvas.width = w * dpr;
            canvas.height = h * dpr;
            canvas.style.width = w + "px";
            canvas.style.height = h + "px";
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        };
        resize();

        const onMove = (e) => {
            mouse.x = e.clientX / w;
            mouse.y = e.clientY / h;
        };

        const draw = (t) => {
            const time = t / 1000;
            ctx.clearRect(0, 0, w, h);
            const small = w < 1024;
            const cx = (small ? 0.5 : 0.72) * w + (mouse.x - 0.5) * 24;
            const cy = (small ? 0.32 : 0.4) * h + (mouse.y - 0.5) * 16;
            const scale = Math.min(w, h) * (small ? 0.24 : 0.3);

            // perspective grid horizon
            const vy = h * 0.78;
            for (let k = -14; k <= 14; k++) {
                ctx.strokeStyle = "rgba(0,255,102,0.055)";
                ctx.beginPath();
                ctx.moveTo(cx + k * (w * 0.055), h + 20);
                ctx.lineTo(cx + k * 14, vy);
                ctx.stroke();
            }
            for (let j = 0; j < 14; j++) {
                const p = (j + ((time * 0.3) % 1)) / 14;
                const y = vy + (h - vy) * Math.pow(p, 1.7);
                ctx.strokeStyle = `rgba(0,255,102,${0.02 + p * 0.05})`;
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(w, y);
                ctx.stroke();
            }

            // rotating 3D shield wireframe
            const a = time * 0.45;
            const proj = (x, y) => {
                const rx = x * Math.cos(a);
                const z = x * Math.sin(a);
                const s = 520 / (520 + z * scale * 0.9);
                return [cx + rx * scale * s, cy + y * scale * s, s];
            };

            ctx.lineWidth = 1;
            ctx.beginPath();
            SHIELD.forEach(([x, y], i) => {
                const [px, py] = proj(x, y);
                if (i) ctx.lineTo(px, py);
                else ctx.moveTo(px, py);
            });
            ctx.closePath();
            ctx.strokeStyle = "rgba(0,255,102,0.34)";
            ctx.stroke();

            ctx.strokeStyle = "rgba(0,255,102,0.1)";
            for (const wx of [-0.42, -0.2, 0, 0.2, 0.42]) {
                ctx.beginPath();
                const [x0, y0] = proj(wx, -0.72);
                const [x1, y1] = proj(wx, bottomY(wx));
                ctx.moveTo(x0, y0);
                ctx.lineTo(x1, y1);
                ctx.stroke();
            }
            for (const hy of [-0.72, -0.42, -0.05, 0.45]) {
                const wh = halfWidth(hy);
                if (wh <= 0) continue;
                ctx.beginPath();
                const [x0, y0] = proj(-wh, hy);
                const [x1, y1] = proj(wh, hy);
                ctx.moveTo(x0, y0);
                ctx.lineTo(x1, y1);
                ctx.stroke();
            }

            for (const tilt of [-0.35, 0.4]) {
                ctx.beginPath();
                for (let i = 0; i <= 60; i++) {
                    const th = (i / 60) * Math.PI * 2;
                    const ex = Math.cos(th) * 0.95;
                    const ey = Math.sin(th) * 0.32;
                    const rx2 = ex * Math.cos(tilt) - ey * Math.sin(tilt);
                    const ry2 = ex * Math.sin(tilt) + ey * Math.cos(tilt);
                    const [px, py] = proj(rx2, ry2);
                    if (i) ctx.lineTo(px, py);
                    else ctx.moveTo(px, py);
                }
                ctx.strokeStyle = "rgba(0,229,255,0.28)";
                ctx.stroke();
            }

            const [kx, ky] = proj(0, 0);
            ctx.fillStyle = `rgba(0,255,102,${0.5 + 0.3 * Math.sin(time * 3)})`;
            ctx.beginPath();
            ctx.arc(kx, ky, 3, 0, Math.PI * 2);
            ctx.fill();

            // drifting particles
            for (const p of particles) {
                p.y -= 0.0004 * p.d;
                if (p.y < -0.02) p.y = 1.02;
                const px = p.x * w + (mouse.x - 0.5) * 30 * p.d + Math.sin(time + p.s) * 8;
                const py = p.y * h;
                ctx.fillStyle = `rgba(0,255,102,${0.1 + 0.16 * p.d})`;
                ctx.fillRect(px, py, p.d > 0.7 ? 2 : 1, p.d > 0.7 ? 2 : 1);
            }

            raf = requestAnimationFrame(draw);
        };
        raf = requestAnimationFrame(draw);
        window.addEventListener("resize", resize);
        window.addEventListener("mousemove", onMove);
        return () => {
            cancelAnimationFrame(raf);
            window.removeEventListener("resize", resize);
            window.removeEventListener("mousemove", onMove);
        };
    }, []);

    return <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none" aria-hidden="true" />;
}
