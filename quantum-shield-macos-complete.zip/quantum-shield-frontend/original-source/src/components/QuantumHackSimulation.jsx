import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Zap, RotateCcw } from "lucide-react";

const ATTACK = [
    [0.0, "INITIALIZING SHOR'S ALGORITHM ENGINE…"],
    [0.4, "Target key: scanned RSA-2048 public key N = e·d"],
    [0.8, "Allocating 4,096 logical qubits in quantum simulator (Qiskit core)…"],
    [1.3, "Constructing quantum circuit for period-finding modular exponentiation f(x) = a^x mod N…"],
    [2.1, "Executing Quantum Fourier Transform (QFT) across superposed qubit register…"],
    [3.0, "Peak detected — measured period r = 2,408,192,491"],
    [3.6, "Calculating GCD(a^(r/2) ± 1, N) via classical coprocessor…"],
    [4.2, "PRIME FACTORS DISCOVERED: p = 134078079299…, q = 108537418931…"],
    [4.8, "RSA PRIVATE KEY RECONSTRUCTED in 4.8s — encryption broken"],
    [5.5, "CONCLUSION: target is vulnerable to harvest-now-decrypt-later Q-Day attack"],
];

const SHIELDED = [
    [0.0, "INITIALIZING SHOR'S ALGORITHM ENGINE…"],
    [0.4, "Target algorithm detected: ML-KEM-768 (module-lattice key encapsulation)"],
    [0.9, "Attempting lattice reduction (BKZ-2.0 / SVP solver on 768-dimensional lattice)…"],
    [1.8, "Quantum memory exceeded — shortest vector problem requires 2^140 quantum operations"],
    [2.9, "Shor's algorithm & Grover's search FAILED — polynomial period finding not applicable"],
    [4.0, "RESULT: target is QUANTUM SHIELDED — lattice hardness verified against Q-Day attack"],
];

function lineClass(t) {
    if (/SHIELDED|FAILED|not applicable/i.test(t)) return "text-qs-green";
    if (/RECONSTRUCTED|DISCOVERED|vulnerable|broken/i.test(t)) return "text-qs-red";
    if (/Peak detected/i.test(t)) return "text-qs-cyan";
    return "text-slate-300";
}

export default function QuantumHackSimulation({ result }) {
    const [lines, setLines] = useState([]);
    const [running, setRunning] = useState(false);
    const [done, setDone] = useState(false);
    const timers = useRef([]);
    const boxRef = useRef(null);

    const clear = () => {
        timers.current.forEach(clearTimeout);
        timers.current = [];
    };

    useEffect(() => clear, []);

    const run = () => {
        if (!result || running) return;
        clear();
        const quantumSafe = ["QUANTUM SHIELDED", "PQC LEADER", "PQC READY", "HYBRID READY"].includes(result.quantumVerdict);
        const script = quantumSafe ? SHIELDED : ATTACK;
        setLines([]);
        setRunning(true);
        setDone(false);
        script.forEach(([t, text], i) => {
            timers.current.push(
                setTimeout(() => {
                    setLines((prev) => [...prev, text]);
                    if (i === script.length - 1) {
                        setRunning(false);
                        setDone(true);
                    }
                    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
                }, 120 + t * 420),
            );
        });
    };

    useEffect(() => {
        clear();
        setLines([]);
        setRunning(false);
        setDone(false);
        if (result?.domain) run();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [result?.domain]);

    return (
        <section id="simulation" data-testid="hack-simulation-section" className="relative py-16 sm:py-24 lg:py-32 border-t qs-hairline">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.15 }}
                    transition={{ duration: 0.8 }}
                    className="flex items-end justify-between flex-wrap gap-6"
                >
                    <div>
                        <p className="font-mono text-[11px] tracking-[0.28em] text-qs-green/80">02 // Q-DAY SIMULATOR</p>
                        <h2 className="font-display font-bold text-3xl sm:text-4xl tracking-tight mt-3 max-w-2xl">
                            WATCH SHOR'S ALGORITHM <span className="text-qs-green qs-text-glow-green">EAT THE KEY.</span>
                        </h2>
                        <p className="mt-3 text-sm text-slate-500 max-w-lg">
                            A narrative simulation of the day a quantum computer factors the target's private key — or bounces off a lattice.
                        </p>
                    </div>
                    <button
                        data-testid="trigger-quantum-sim-button"
                        onClick={run}
                        disabled={!result || running}
                        className="flex items-center gap-2 font-mono text-[11px] font-bold tracking-[0.2em] border border-qs-green/40 text-qs-green bg-qs-green/5 hover:bg-qs-green/15 hover:shadow-[0_0_30px_rgba(0,255,102,0.2)] rounded-md px-5 py-3 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                        {running ? (
                            "ATTACK IN PROGRESS…"
                        ) : (
                            <>
                                {done ? <RotateCcw className="h-4 w-4" /> : <Zap className="h-4 w-4" />}
                                {done ? "RE-RUN SIMULATION" : "RUN Q-DAY SIMULATION"}
                            </>
                        )}
                    </button>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.1 }}
                    transition={{ duration: 0.8, delay: 0.15 }}
                    className="mt-10 qs-glass qs-term-shadow rounded-lg overflow-hidden"
                >
                    <div className="flex items-center justify-between px-5 py-3 border-b qs-hairline">
                        <div className="flex items-center gap-1.5">
                            <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
                            <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
                            <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
                        </div>
                        <p className="font-mono text-[10px] tracking-[0.2em] text-slate-500 truncate">
                            shor_attack_engine — qiskit core — {result ? result.domain : "no target"}
                        </p>
                    </div>
                    <div ref={boxRef} data-testid="sim-terminal-output" className="h-72 overflow-y-auto px-5 sm:px-7 py-5 font-mono text-[11px] sm:text-sm leading-7">
                        <p className="text-slate-500">$ qshield attack --target {result ? result.domain : "—"} --engine shor --qubits 4096</p>
                        {lines.map((l, i) => (
                            <motion.p key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.25 }} className={lineClass(l)}>
                                <span className="text-slate-700 mr-2">{String(i + 1).padStart(2, "0")}</span>
                                {l}
                            </motion.p>
                        ))}
                        {running && <p className="text-qs-green qs-caret">▌</p>}
                        {!result && (
                            <p className="text-slate-600 mt-3">
                                Awaiting target — run a scan above to arm the simulator.
                            </p>
                        )}
                    </div>
                </motion.div>
            </div>
        </section>
    );
}
