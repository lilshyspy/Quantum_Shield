import { motion } from "framer-motion";

export default function ScanAnimation({ domain, stageIdx, stages }) {
    const pct = Math.round(((stageIdx + 1) / stages.length) * 100);
    return (
        <div data-testid="scanning-animation-container" className="qs-glass qs-term-shadow rounded-lg overflow-hidden max-w-3xl">
            <div className="flex items-center justify-between px-5 py-3 border-b qs-hairline">
                <div className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
                </div>
                <p className="font-mono text-[10px] tracking-[0.2em] text-slate-500 truncate">
                    QUANTUM-SHIELD v2.4 — LIVE DIAGNOSTICS — <span className="text-qs-green">{domain}</span>
                </p>
            </div>

            <div className="relative px-6 sm:px-8 py-8 font-mono text-xs sm:text-sm min-h-[300px]">
                <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-qs-green/60 to-transparent qs-scanline" />
                {stages.slice(0, stageIdx + 1).map((s, i) => (
                    <motion.p
                        key={s}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`py-1.5 ${i === stageIdx ? "text-qs-green" : "text-slate-400"}`}
                    >
                        <span className="text-slate-600 mr-2">[{(i * 0.48 + 0.1).toFixed(2)}s]</span>
                        <span className="text-slate-600 mr-1">&gt;</span>
                        {s}
                        {i === stageIdx && <span className="qs-caret ml-1">▌</span>}
                    </motion.p>
                ))}

                <div className="mt-8 h-1 bg-white/5 rounded-full overflow-hidden">
                    <motion.div className="h-full bg-qs-green" animate={{ width: `${pct}%` }} transition={{ duration: 0.4 }} />
                </div>
                <p className="mt-2 text-right text-[10px] text-slate-500 tracking-widest">{pct}% — ANALYZING {domain}</p>
            </div>
        </div>
    );
}
