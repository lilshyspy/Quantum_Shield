import { motion } from "framer-motion";
import { Trash2, RefreshCw } from "lucide-react";
import { VERDICT_COLOR_FALLBACK } from "./verdictColors";

const ago = (ts) => {
    const m = Math.floor((Date.now() - ts) / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
};

function Chip({ verdict, score, prefix }) {
    const color = VERDICT_COLOR_FALLBACK[verdict] || "#00E5FF";
    return (
        <span
            title={verdict}
            className="font-mono text-[10px] px-2 py-1 rounded border whitespace-nowrap"
            style={{ color, borderColor: `${color}44`, background: `${color}0d` }}
        >
            {prefix} {score}
        </span>
    );
}

export default function ScanHistory({ history, onRescan, onClear }) {
    return (
        <section id="history" data-testid="scan-history-section" className="relative py-16 sm:py-24 border-t qs-hairline">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.15 }}
                    transition={{ duration: 0.7 }}
                    className="flex items-end justify-between flex-wrap gap-4"
                >
                    <div>
                        <p className="font-mono text-[11px] tracking-[0.28em] text-qs-green/80">04 // RECENT SCANS</p>
                        <h2 className="font-display font-bold text-2xl sm:text-3xl tracking-tight mt-2">SCAN LOG — STORED IN YOUR BROWSER</h2>
                    </div>
                    {history.length > 0 && (
                        <button
                            data-testid="clear-scan-history-button"
                            onClick={onClear}
                            className="flex items-center gap-2 font-mono text-[11px] tracking-[0.18em] text-slate-500 hover:text-qs-red border qs-hairline rounded-md px-4 py-2 transition-colors duration-200"
                        >
                            <Trash2 className="h-3.5 w-3.5" /> PURGE LOG
                        </button>
                    )}
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.1 }}
                    transition={{ duration: 0.7, delay: 0.1 }}
                    className="mt-8 qs-glass rounded-lg divide-y divide-white/5"
                >
                    {history.length === 0 ? (
                        <p data-testid="scan-history-empty" className="px-6 py-12 text-center font-mono text-xs text-slate-600 tracking-widest">
                            NO ENTRIES — RUN YOUR FIRST SCAN ABOVE
                        </p>
                    ) : (
                        history.map((h, i) => (
                            <div
                                key={`${h.domain}-${h.ts}`}
                                data-testid={`scan-history-item-${i}`}
                                className="flex items-center gap-3 sm:gap-4 px-4 sm:px-6 py-4 hover:bg-white/[0.02] transition-colors duration-200"
                            >
                                <span className="font-mono text-[10px] text-slate-600 w-6 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                                <button
                                    onClick={() => onRescan(h.domain)}
                                    className="flex-1 min-w-0 text-left font-mono text-xs sm:text-sm text-[#F0F4F1] hover:text-qs-green transition-colors duration-200 truncate"
                                >
                                    {h.domain}
                                </button>
                                <Chip verdict={h.classicalVerdict} score={h.classicalScore} prefix="C" />
                                <Chip verdict={h.quantumVerdict} score={h.quantumScore} prefix="Q" />
                                <span className="hidden sm:block font-mono text-[10px] text-slate-600 w-16 text-right shrink-0">{ago(h.ts)}</span>
                                <button
                                    data-testid={`scan-history-rescan-${i}`}
                                    onClick={() => onRescan(h.domain)}
                                    title={`Re-scan ${h.domain}`}
                                    className="text-slate-500 hover:text-qs-green transition-colors duration-200 shrink-0"
                                >
                                    <RefreshCw className="h-3.5 w-3.5" />
                                </button>
                            </div>
                        ))
                    )}
                </motion.div>
            </div>
        </section>
    );
}
