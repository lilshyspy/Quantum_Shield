import { useEffect, useState } from "react";

const fmt = (n) => Math.round(n).toLocaleString("en-US");

export default function ThreatTicker() {
    const [stats, setStats] = useState({ hndl: 38412905, qubits: 1101, pqc: 21.7 });

    useEffect(() => {
        const id = setInterval(() => {
            setStats((s) => ({
                hndl: s.hndl + 120 + Math.floor(Math.random() * 340),
                qubits: s.qubits + (Math.random() < 0.15 ? 1 : 0),
                pqc: Math.max(19, Math.min(24, +(s.pqc + (Math.random() - 0.5) * 0.2).toFixed(1))),
            }));
        }, 1600);
        return () => clearInterval(id);
    }, []);

    const cells = [
        ["ESTIMATED Q-DAY WINDOW", "2029 — 2033", "text-qs-cyan"],
        ["RECORDED TRAFFIC EXPOSED TO HNDL", `${fmt(stats.hndl)} GB`, "text-qs-amber"],
        ["CRYPTO-RELEVANT QUBITS (RECORD)", fmt(stats.qubits), "text-qs-red"],
        ["TOP-1M SITES PQC-READY", `${stats.pqc.toFixed(1)} %`, "text-qs-green"],
    ];

    return (
        <div data-testid="threat-statistics-ticker" className="relative border-y qs-hairline bg-qs-term/60">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 lg:grid-cols-4 divide-x divide-white/5">
                {cells.map(([label, value, color], i) => (
                    <div key={label} className={`px-4 sm:px-6 py-5 sm:py-6 ${i < 2 ? "border-b border-white/5 lg:border-b-0" : ""}`}>
                        <p className="font-mono text-[9px] sm:text-[10px] tracking-[0.18em] text-slate-500 leading-4">{label}</p>
                        <p className={`mt-2 font-mono text-sm sm:text-lg font-medium ${color}`} data-testid={`threat-ticker-value-${i}`}>
                            {value}
                        </p>
                    </div>
                ))}
            </div>
            <span className="absolute right-3 top-1.5 font-mono text-[8px] tracking-[0.2em] text-slate-700">
                // SIMULATED TELEMETRY
            </span>
        </div>
    );
}
