#!/bin/bash
set -euo pipefail
FRONTEND_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND_DIR="${QS_BACKEND_DIR:-$HOME/Downloads/QuantumShield/backend}"
PYTHON_BIN="${QS_PYTHON:-$(command -v python3)}"
if ! "$PYTHON_BIN" -c 'import sys; assert sys.version_info >= (3,11)' 2>/dev/null; then
  PYTHON_BIN=/opt/homebrew/bin/python3
fi
if ! "$PYTHON_BIN" -c 'import sys; assert sys.version_info >= (3,11)' 2>/dev/null; then
  echo 'Python 3.11+ is required. Install a current Python for macOS; Python 3.15 enables negotiated-group detection.'; exit 1
fi
if [ ! -f "$BACKEND_DIR/main.py" ]; then echo "Backend not found at $BACKEND_DIR. Set QS_BACKEND_DIR to its location."; exit 1; fi
# A Windows venv cannot be reused. Keep it intact and create a separate macOS .venv.
if [ ! -x "$BACKEND_DIR/.venv/bin/python" ]; then "$PYTHON_BIN" -m venv "$BACKEND_DIR/.venv"; fi
"$BACKEND_DIR/.venv/bin/python" -m pip install -r "$BACKEND_DIR/requirements-lock.txt"
cd "$FRONTEND_DIR"
npm ci
echo 'Setup complete. Run npm run start:mac or use the VS Code Start Quantum Shield task.'
