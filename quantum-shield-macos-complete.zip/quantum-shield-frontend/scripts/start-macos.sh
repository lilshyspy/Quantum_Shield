#!/bin/bash
set -euo pipefail
FRONTEND_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND_DIR="${QS_BACKEND_DIR:-$HOME/Downloads/QuantumShield/backend}"
if [ ! -x "$BACKEND_DIR/.venv/bin/python" ] || [ ! -d "$FRONTEND_DIR/node_modules" ]; then
  echo 'Run npm run setup:mac first.'; exit 1
fi
for port in 8000 5173; do
  if /usr/sbin/lsof -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1; then
    echo "Port $port is already in use. Stop the existing Quantum Shield task before starting again."; exit 1
  fi
done
cd "$BACKEND_DIR"
"$BACKEND_DIR/.venv/bin/python" -m uvicorn main:app --host 127.0.0.1 --port 8000 &
BACKEND_PID=$!
FRONTEND_PID=''
cleanup() { kill "$BACKEND_PID" 2>/dev/null || true; if [ -n "$FRONTEND_PID" ]; then kill "$FRONTEND_PID" 2>/dev/null || true; fi; }
trap cleanup EXIT INT TERM
for attempt in {1..40}; do
  if curl --silent --fail http://127.0.0.1:8000/api/health >/dev/null; then break; fi
  if ! kill -0 "$BACKEND_PID" 2>/dev/null; then echo 'Backend failed to start.'; exit 1; fi
  sleep 0.25
done
curl --silent --fail http://127.0.0.1:8000/api/health >/dev/null || { echo 'Backend did not become ready.'; exit 1; }
cd "$FRONTEND_DIR"
node node_modules/vite/bin/vite.js --host 127.0.0.1 &
FRONTEND_PID=$!
echo 'Quantum Shield: http://localhost:5173 — API docs: http://localhost:8000/docs'
wait "$FRONTEND_PID"
