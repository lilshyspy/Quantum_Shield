import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { SendHorizonal } from "lucide-react";
import { apiUrl, API_BASE_URL, SCAN_MODE } from "@/lib/api";

const GENERAL_CHIPS = [
    "What is harvest-now-decrypt-later?",
    "Which encryption survives quantum computers?",
    "What exactly is Q-Day?",
];

export default function AIAnalyst({ result }) {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const [streaming, setStreaming] = useState(false);
    const boxRef = useRef(null);
    const resultRef = useRef(null);
    resultRef.current = result;

    const [sessionId] = useState(() => {
        let s = localStorage.getItem("qs_session_id");
        if (!s) {
            s = crypto.randomUUID ? crypto.randomUUID() : `sess-${Date.now()}-${Math.random().toString(36).slice(2)}`;
            localStorage.setItem("qs_session_id", s);
        }
        return s;
    });

    useEffect(() => {
        if (SCAN_MODE === "demo" && !API_BASE_URL) return;
        fetch(apiUrl(`/api/ai/analyst/history/${encodeURIComponent(sessionId)}`))
            .then((r) => r.json())
            .then((d) => {
                if (Array.isArray(d)) setMessages(d);
            })
            .catch(() => {});
    }, [sessionId]);

    useEffect(() => {
        boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
    }, [messages, streaming]);

    const patchLast = (fn) =>
        setMessages((m) => {
            const c = [...m];
            c[c.length - 1] = fn(c[c.length - 1]);
            return c;
        });

    const send = async (text) => {
        const msg = (text ?? input).trim();
        if (!msg || streaming) return;
        if (SCAN_MODE === "demo" && !API_BASE_URL) {
            setInput("");
            setMessages((m) => [...m, { role: "user", content: msg }, {
                role: "assistant", content: "The frontend is running in demo mode. Connect the AI Analyst backend to enable chat.",
            }]);
            return;
        }
        setInput("");
        setMessages((m) => [...m, { role: "user", content: msg }, { role: "assistant", content: "" }]);
        setStreaming(true);
        try {
            const res = await fetch(apiUrl("/api/ai/analyst"), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    session_id: sessionId,
                    message: msg,
                    scan_context: resultRef.current || null,
                }),
            });
            if (!res.ok || !res.body) throw new Error("The analyst request failed.");
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buf = "";
            for (;;) {
                const { value, done } = await reader.read();
                if (done) break;
                buf += decoder.decode(value, { stream: true });
                const parts = buf.split("\n\n");
                buf = parts.pop();
                for (const part of parts) {
                    const line = part.trim();
                    if (!line.startsWith("data:")) continue;
                    try {
                        const j = JSON.parse(line.slice(5).trim());
                        if (j.delta) patchLast((m) => ({ ...m, content: m.content + j.delta }));
                        if (j.error) patchLast((m) => ({ ...m, content: j.error }));
                    } catch {}
                }
            }
        } catch {
            patchLast((m) => ({ ...m, content: "Connection to the analyst dropped — please try again." }));
        }
        setStreaming(false);
    };

    const chips = result
        ? [
              `Why is ${result.domain} rated ${result.quantumVerdict}?`,
              `How do I secure ${result.domain} before Q-Day?`,
              "Explain the detected encryption suite.",
          ]
        : GENERAL_CHIPS;

    return (
        <section
            id="analyst"
            data-testid="ai-analyst-section"
            className="relative py-16 sm:py-24 lg:py-32 border-t qs-hairline"
        >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.15 }}
                    transition={{ duration: 0.8 }}
                >
                    <p className="font-mono text-[11px] tracking-[0.28em] text-qs-green/80">03 // AI SECURITY ANALYST — CHATGPT</p>
                    <h2 className="font-display font-bold text-3xl sm:text-4xl tracking-tight mt-3 max-w-2xl">
                        ASK THE ANALYST <span className="text-qs-green qs-text-glow-green">WHY IT MATTERS.</span>
                    </h2>
                    <p className="mt-3 text-sm text-slate-500 max-w-lg">
                        A ChatGPT cryptography analyst, grounded in your latest scan report — streamed live, kept in your session.
                    </p>
                </motion.div>

                <p className="mt-3 text-xs text-slate-400">Current connection: local report assistant. ChatGPT-powered answers require a separately configured model service.</p>

                <div className="mt-6 flex flex-wrap gap-2">
                    {chips.map((c) => (
                        <button
                            key={c}
                            onClick={() => send(c)}
                            disabled={streaming}
                            className="font-mono text-[11px] px-3 py-1.5 rounded-full border qs-hairline text-slate-300 hover:border-qs-green/50 hover:text-qs-green bg-qs-term/50 transition-colors duration-200 disabled:opacity-40"
                        >
                            {c}
                        </button>
                    ))}
                </div>

                <motion.div
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.1 }}
                    transition={{ duration: 0.8, delay: 0.1 }}
                    className="mt-6 qs-glass qs-term-shadow rounded-lg overflow-hidden"
                >
                    <div className="flex items-center justify-between px-5 py-3 border-b qs-hairline">
                        <div className="flex items-center gap-1.5">
                            <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
                            <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
                            <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
                        </div>
                        <p className="font-mono text-[10px] tracking-[0.2em] text-slate-500 truncate">
                            gpt-5.4 — quantum shield analyst — session {sessionId.slice(0, 8)}
                        </p>
                    </div>

                    <div
                        ref={boxRef}
                        data-testid="ai-chat-output"
                        className="h-[380px] overflow-y-auto px-5 sm:px-7 py-5 font-mono text-[11px] sm:text-sm leading-7 space-y-4"
                    >
                        {messages.length === 0 && (
                            <p className="text-slate-600">
                                analyst ready — ask anything about classical threats, post-quantum migration, or your latest scan.
                                {result ? "" : " Run a scan above for target-specific answers."}
                            </p>
                        )}
                        {messages.map((m, i) => (
                            <div key={m.id || i} data-testid={`ai-chat-message-${i}`}>
                                <p
                                    className={`text-[10px] tracking-[0.2em] mb-0.5 ${
                                        m.role === "user" ? "text-qs-cyan" : "text-qs-green"
                                    }`}
                                >
                                    {m.role === "user" ? "YOU@SHIELD:~$" : "ANALYST//GPT-5.4"}
                                </p>
                                <p className="text-slate-200 whitespace-pre-wrap">
                                    {m.content}
                                    {streaming && i === messages.length - 1 && m.role === "assistant" && (
                                        <span className="qs-caret ml-1">▌</span>
                                    )}
                                </p>
                            </div>
                        ))}
                    </div>

                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                            send();
                        }}
                        className="flex items-center gap-3 border-t qs-hairline px-5 py-4"
                    >
                        <input
                            data-testid="ai-chat-input"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder={result ? `Ask about ${result.domain}…` : "Ask about post-quantum security…"}
                            spellCheck="false"
                            className="qs-input flex-1 h-11 px-4 rounded-md bg-qs-term/80 border qs-hairline font-mono text-xs sm:text-sm text-[#F0F4F1] placeholder:text-slate-600 transition-all duration-200"
                        />
                        <button
                            data-testid="ai-chat-send-button"
                            type="submit"
                            disabled={streaming || !input.trim()}
                            className="h-11 w-11 rounded-md bg-qs-green text-qs-base flex items-center justify-center hover:bg-[#4dffa0] hover:shadow-[0_0_30px_rgba(0,255,102,0.3)] transition-all duration-200 disabled:opacity-40 shrink-0"
                        >
                            <SendHorizonal className="h-4 w-4" />
                        </button>
                    </form>
                </motion.div>
            </div>
        </section>
    );
}
