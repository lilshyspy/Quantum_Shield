import { createPortal } from "react-dom";
import { ShieldCheck, Printer, ArrowUpRight, Fingerprint } from "lucide-react";
import Logo from "./Logo";
import "./Certificate.css";

const formatDate = (value) => {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "Not available" : date.toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" }) + " UTC";
};
const scoreColor = (score) => score >= 85 ? "#70ffb1" : score >= 60 ? "#72e7ff" : score >= 30 ? "#ffd080" : "#ff8994";

function Score({ label, score, verdict }) {
    return <div className="qs-cert-score" style={{ "--score-color": scoreColor(score) }}>
        <span>{label}</span><div><strong>{score}</strong><small>/ 100</small></div>
        <div className="qs-cert-meter"><i style={{ width: `${score}%` }} /></div><b>{verdict}</b>
    </div>;
}
function Detail({ label, value }) {
    return <div><dt>{label}</dt><dd>{value || "Not available"}</dd></div>;
}
function Breakdown({ title, rows }) {
    return <div className="qs-cert-breakdown"><h5>{title}</h5>{rows?.length ? rows.map(row => <div key={row.check}><span>{row.check}</span><b>{row.earned} / {row.maximum}</b></div>) : <p>Detailed scoring evidence is unavailable for this report.</p>}</div>;
}

export default function Certificate({ result }) {
    const evidence = result.evidence || {};
    const reference = result.reportId || `QS-${Array.from(`${result.domain}:${result.scannedAt}`).reduce((h, c) => (Math.imul(31, h) + c.charCodeAt(0)) >>> 0, 0).toString(16).toUpperCase().padStart(8, "0")}`;
    const limitations = result.limitations || ["This report uses demonstration data and does not verify the target’s live configuration."];
    const document = <div className="qs-cert-document">
        <article className="qs-certificate qs-cert-cover" aria-label={`Quantum Shield certificate for ${result.domain}`}>
            <header className="qs-cert-top"><div className="qs-cert-brand"><Logo /><div>QUANTUM<span>SHIELD</span><small>CRYPTOGRAPHIC SECURITY INTELLIGENCE</small></div></div><div className="qs-cert-edition">ASSESSMENT SERIES <b>QS / 02</b></div></header>
            <div className="qs-cert-title-row"><div><p className="qs-cert-eyebrow">SECURITY ASSURANCE RECORD</p><h3>Certificate of<br /><em>Quantum Readiness</em></h3><p className="qs-cert-intro">A documented assessment of classical security<br />and preparedness for the post-quantum era.</p></div><div className="qs-cert-seal"><ShieldCheck size={35} /><strong>QS CERTIFIED</strong><span>ASSESSMENT RECORD</span><small>{result.simulated ? "DEMONSTRATION" : "LIVE TLS INSPECTION"}</small></div></div>
            <div className="qs-cert-target"><span>ASSESSED DIGITAL PROPERTY</span><h4>{result.domain}</h4><p>HTTPS ENDPOINT · PORT 443 <ArrowUpRight size={12} /></p></div>
            <div className="qs-cert-scores"><Score label="01 / CLASSICAL SECURITY" score={result.classicalScore} verdict={result.classicalVerdict} /><Score label="02 / QUANTUM READINESS" score={result.quantumScore} verdict={result.quantumVerdict} /></div>
            <p className="qs-cert-scale">0–100 SAFETY SCALE <span>Higher scores indicate greater observed safety and readiness.</span></p>
            <section className="qs-cert-observation"><p className="qs-cert-eyebrow">ASSESSMENT OUTCOME</p><h5>{result.pqcStatus}</h5><p>{result.qdayVulnerability}</p></section>
            <dl className="qs-cert-details"><Detail label="TLS PROTOCOL" value={result.crypto.tlsVersion} /><Detail label="NEGOTIATED KEY EXCHANGE" value={result.crypto.keyExchange} /><Detail label="SIGNATURE ALGORITHM" value={result.crypto.sigAlgorithm} /><Detail label="CERTIFICATE" value={result.crypto.certificate} /></dl>
            <footer className="qs-cert-footer"><div><span>ISSUED AT</span><b>{formatDate(result.scannedAt)}</b></div><div><span>REPORT REFERENCE</span><b>{reference}</b></div><div className="qs-cert-authority"><ShieldCheck size={18} /><b>Quantum Shield<small>Automated assessment</small></b></div></footer>
            <p className="qs-cert-note">QS CERTIFIED identifies this assessment record, not an independent accreditation or a guarantee of security. Results describe the endpoint observed at the time of inspection. {result.simulated ? "Demonstration data — not a live scan." : "Scope and supporting evidence follow in the technical appendix."}</p>
            <div className="qs-cert-page"><span>QUANTUM SHIELD / CONFIDENCE THROUGH EVIDENCE</span><span>01 / 02</span></div>
        </article>
        <article className="qs-certificate qs-cert-appendix" aria-label="Certificate technical appendix">
            <header className="qs-cert-top"><div className="qs-cert-brand"><Logo /><div>QUANTUM<span>SHIELD</span><small>SUPPORTING EVIDENCE & METHODOLOGY</small></div></div><div className="qs-cert-edition">TECHNICAL APPENDIX <b>QS / 02</b></div></header>
            <div className="qs-cert-appendix-title"><p className="qs-cert-eyebrow">{reference}</p><h3>Behind the assessment.</h3><p>{result.domain} · {formatDate(result.scannedAt)}</p></div>
            <section><h4 className="qs-cert-section-title">01 / OBSERVED CONFIGURATION</h4><dl className="qs-cert-details"><Detail label="CIPHER SUITE" value={evidence.cipher} /><Detail label="CERTIFICATE EXPIRY" value={evidence.expiresAt ? formatDate(evidence.expiresAt) : null} /><Detail label="HSTS" value={result.crypto.hsts} /><Detail label="DNSSEC" value={result.crypto.dnssec} /><Detail label="CERTIFICATE ISSUER" value={evidence.issuer} /><Detail label="INSPECTED ADDRESS" value={evidence.address} /></dl>{evidence.fingerprint && <div className="qs-cert-fingerprint"><Fingerprint size={15} /><div><span>CERTIFICATE SHA-256 FINGERPRINT</span><code>{evidence.fingerprint.match(/.{1,2}/g).join(":")}</code></div></div>}</section>
            <section><h4 className="qs-cert-section-title">02 / SCORE METHODOLOGY <span>{result.scoreMethod?.version || "DEMO"}</span></h4><div className="qs-cert-breakdowns"><Breakdown title="Classical safety" rows={result.scoreMethod?.classical} /><Breakdown title="Quantum readiness" rows={result.scoreMethod?.quantum} /></div><p className="qs-cert-note">Points are awarded for observed controls. Unverified checks earn no points; a low score can reflect limited evidence. These scores are an assessment rubric, not a statistical probability of safety.</p></section>
            <section><h4 className="qs-cert-section-title">03 / REMEDIATION QUEUE</h4><ol className="qs-cert-recommendations">{result.recommendations.map((item, index) => <li key={index}><span>{String(index + 1).padStart(2, "0")}</span>{item}</li>)}</ol></section>
            <section><h4 className="qs-cert-section-title">04 / SCOPE & LIMITATIONS</h4><ul className="qs-cert-limitations">{limitations.map((item, index) => <li key={index}>{item}</li>)}</ul></section>
            <div className="qs-cert-page"><span>QUANTUM SHIELD / {reference}</span><span>02 / 02</span></div>
        </article>
    </div>;
    return <>
        <section className="qs-cert-section" data-testid="assessment-certificate"><div className="qs-cert-toolbar"><div><p>YOUR ASSESSMENT CERTIFICATE</p><span>A formal record. A clear path forward.</span></div><button type="button" onClick={() => window.print()}><Printer size={16} /> Print / Save as PDF</button></div>{document}</section>
        {createPortal(<div className="qs-certificate-print">{document}</div>, window.document.body)}
    </>;
}
