import { motion } from "framer-motion";
import { ShieldCheck, Atom, ChevronRight } from "lucide-react";

import Certificate from "./Certificate";

const VERDICT_COLOR = {
    SECURE: "#00FF66",
    CAUTION: "#FFB800",
    VULNERABLE: "#FF3344",
    "QUANTUM SHIELDED": "#00FF66",
    "PQC LEADER": "#00FF66",
    "PQC READY": "#00FF66",
    "HYBRID READY": "#00E5FF",
    "AT RISK": "#FFB800",
    "CRITICAL RISK": "#FF3344",
};

function Gauge({ score }) {
    const color = score >= 85 ? "#00FF66" : score >= 60 ? "#00E5FF" : score >= 30 ? "#FFB800" : "#FF3344";
    return (
        <div className="relative" data-testid="risk-score-gauge">
            <svg viewBox="0 0 240 132" className="w-full max-w-[280px] mx-auto block">
                <path d="M 20 122 A 100 100 0 0 1 220 122" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="10" strokeLinecap="round" />
                <motion.path
                    d="M 20 122 A 100 100 0 0 1 220 122"
                    fill="none"
                    stroke={color}
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray="314.2"
                    initial={{ strokeDashoffset: 314.2 }}
                    animate={{ strokeDashoffset: 314.2 * (1 - score / 100) }}
                    transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
                    style={{ filter: `drop-shadow(0 0 10px ${color}55)` }}
                />
            </svg>
            <div className="absolute inset-x-0 bottom-0 text-center">
                <span className="font-mono text-4xl sm:text-5xl font-bold" style={{ color, textShadow: `0 0 28px ${color}55` }}>
                    {score}
                </span>
                <span className="font-mono text-xs text-slate-600">/100</span>
            </div>
        </div>
    );
}

function VerdictBadge({ icon: Icon, label, verdict, score, testid }) {
    const color = VERDICT_COLOR[verdict] || "#00E5FF";
    return (
        <div className="qs-glass rounded-lg p-5 sm:p-6 h-full">
            <div className="flex items-center justify-between">
                <p className="font-mono text-[10px] tracking-[0.22em] text-slate-500">{label}</p>
                <Icon className="h-4 w-4" style={{ color }} />
            </div>
            <p
                data-testid={testid}
                className="mt-3 font-display font-bold text-xl sm:text-2xl tracking-tight"
                style={{ color, textShadow: `0 0 24px ${color}55` }}
            >
                {verdict}
            </p>
            <div className="mt-4 flex items-center gap-3">
                <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                        className="h-full rounded-full"
                        style={{ background: color }}
                        initial={{ width: 0 }}
                        animate={{ width: `${score}%` }}
                        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
                    />
                </div>
                <span className="font-mono text-xs text-slate-400 shrink-0">{score}/100</span>
            </div>
        </div>
    );
}

function CryptoRow({ k, v, accent }) {
    return (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 py-3 border-b border-white/5 last:border-0">
            <span className="font-mono text-[10px] tracking-[0.2em] text-slate-500">{k}</span>
            <span className="font-mono text-xs sm:text-sm sm:text-right" style={{ color: accent ? "#00FF66" : "#F0F4F1" }}>
                {v}
            </span>
        </div>
    );
}

export default function VerdictReport({ result }) {
    const qColor = VERDICT_COLOR[result.quantumVerdict] || "#00E5FF";
    const pqAccent = /ML-KEM|Kyber|ML-DSA|hybrid|post-quantum/i.test(result.crypto.keyExchange) || /PQ|post-quantum/i.test(result.pqcStatus);

    return (
        <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
        >
            <div className="grid lg:grid-cols-12 gap-6">
                <div className="lg:col-span-4 qs-glass rounded-lg p-6 flex flex-col">
                    <div className="flex items-center justify-between">
                        <p className="font-mono text-[10px] tracking-[0.22em] text-slate-500">QUANTUM SHIELD SCORE</p>
                        <span className="flex items-center gap-1.5 font-mono text-[9px] tracking-widest text-slate-600 border qs-hairline rounded px-2 py-1">
                            <ShieldCheck className="h-3 w-3" /> QS CERTIFIED
                        </span>
                    </div>
                    <div className="py-6 flex-1 flex items-center">
                        <Gauge score={result.quantumScore} />
                    </div>
                    <p className="text-center font-mono text-[10px] tracking-[0.2em] text-slate-600">
                        Q-READINESS FOR {result.domain.toUpperCase()}
                    </p>
                </div>

                <div className="lg:col-span-8 grid sm:grid-cols-2 gap-6">
                    <VerdictBadge
                        icon={ShieldCheck}
                        label="CLASSICAL COMPUTERS — TODAY"
                        verdict={result.classicalVerdict}
                        score={result.classicalScore}
                        testid="classical-verdict-badge"
                    />
                    <VerdictBadge
                        icon={Atom}
                        label="QUANTUM COMPUTERS — NEXT DECADE"
                        verdict={result.quantumVerdict}
                        score={result.quantumScore}
                        testid="quantum-verdict-badge"
                    />

                    <div className="sm:col-span-2 qs-glass rounded-lg p-5 sm:p-6" data-testid="encryption-suite-card">
                        <p className="font-mono text-[10px] tracking-[0.22em] text-slate-500 mb-2">ENCRYPTION SUITE — DETECTED</p>
                        <CryptoRow k="TLS VERSION" v={result.crypto.tlsVersion} />
                        <CryptoRow k="KEY EXCHANGE" v={result.crypto.keyExchange} accent={/MLKEM|Kyber|ML-/.test(result.crypto.keyExchange)} />
                        <CryptoRow k="SIGNATURE" v={result.crypto.sigAlgorithm} />
                        <CryptoRow k="CERTIFICATE" v={result.crypto.certificate} />
                        <CryptoRow k="HSTS" v={result.crypto.hsts} accent={/^Enabled/i.test(result.crypto.hsts)} />
                        <CryptoRow k="DNSSEC" v={result.crypto.dnssec} accent={/Validated|Signed/i.test(result.crypto.dnssec)} />
                        <CryptoRow k="PQC STATUS" v={result.pqcStatus} accent={pqAccent} />
                    </div>
                </div>
            </div>

            <div className="grid lg:grid-cols-12 gap-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.7 }}
                    className="lg:col-span-5 qs-glass rounded-lg p-6 border-l-2"
                    style={{ borderLeftColor: qColor }}
                    data-testid="qday-exposure-card"
                >
                    <p className="font-mono text-[10px] tracking-[0.22em] text-slate-500">Q-DAY EXPOSURE</p>
                    <p className="mt-3 font-mono text-sm leading-relaxed" style={{ color: qColor }}>
                        {result.qdayVulnerability}
                    </p>
                    <p className="mt-4 text-xs text-slate-500 leading-relaxed">
                        Adversaries can record traffic to <span className="font-mono text-slate-300">{result.domain}</span> today and decrypt
                        it the day a cryptographically-relevant quantum computer exists. Estimated window: 2029–2033.
                    </p>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.7, delay: 0.1 }}
                    className="lg:col-span-7 qs-glass rounded-lg p-6"
                    data-testid="recommendations-list"
                >
                    <p className="font-mono text-[10px] tracking-[0.22em] text-slate-500 mb-4">REMEDIATION QUEUE</p>
                    <div className="grid sm:grid-cols-2 gap-x-8 gap-y-4">
                        {result.recommendations.map((r, i) => (
                            <div key={r} className="flex items-start gap-3">
                                <span className="font-mono text-[10px] text-qs-green/70 mt-0.5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                                <p className="text-xs sm:text-[13px] leading-relaxed text-slate-300 flex-1">{r}</p>
                                <ChevronRight className="h-3.5 w-3.5 text-slate-600 mt-0.5 shrink-0" />
                            </div>
                        ))}
                    </div>
                </motion.div>
            </div>
            <Certificate result={result} />
        </motion.div>
    );
}
